@echo off
cd /d "%~dp0"
start "" "ESP32-PinLab.exe"
